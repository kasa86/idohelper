import ProductDetailsCard from '@/app/(auth)/product-details/_producct-details-card'

export default function ProductDetails() {
    return <ProductDetailsCard />
}
