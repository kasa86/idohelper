export default async function NoAuthLayout({
    children,
}: Readonly<{
    children: React.ReactNode
}>) {
    return children
}
